import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:blue_thermal_printer/blue_thermal_printer.dart';
import '../../../core/errors/error_logger.dart';
import '../../../core/errors/error_types.dart';
import '../../../data/providers.dart';

class BillingPrintService {
  final BlueThermalPrinter _bluePrinter = BlueThermalPrinter.instance;

  Future<void> attemptPrintSavedBill(
    ScaffoldMessengerState messenger,
    WidgetRef ref, {
    required int billId,
    required bool allowRetry,
    required GlobalKey desktopKey,
    required GlobalKey mobileKey,
    required bool Function() isMounted,
    required VoidCallback onClearDraft,
  }) async {
    try {
      final billRepo = ref.read(billRepositoryProvider);

      final savedBill = await billRepo.getById(billId);
      final savedBillItems = await billRepo.getBillItems(billId);
      if (savedBill == null || savedBillItems.isEmpty) {
        throw StateError('PRINT_001');
      }

      final connected = await _bluePrinter.isConnected ?? false;
      if (!connected) {
        throw StateError('PRINT_001');
      }

      final billImageBytes = await captureBillImageBytes(desktopKey, mobileKey);
      if (billImageBytes == null) {
        throw StateError('PRINT_001');
      }

      await _bluePrinter.writeBytes(billImageBytes);
      if (!isMounted()) return;
      onClearDraft();
      messenger.showSnackBar(
        const SnackBar(content: Text('બિલ પ્રિન્ટ થઈ રહ્યું છે.')),
      );
    } catch (error, stack) {
      final appError = AppError(
        code: 'PRINT_001',
        category: ErrorCategory.printing,
        technicalMessage: error.toString(),
        userMessage: 'પ્રિન્ટર સાથે જોડાણ નિષ્ફળ. કૃપા કરીને તપાસો કે પ્રિન્ટર ચાલુ છે.',
        isCritical: false,
        timestamp: DateTime.now(),
        stackTrace: stack,
      );
      await ErrorLogger.log(
        appError,
        currentScreen: 'BillingPrintService.attemptPrintSavedBill',
      );

      if (!isMounted()) return;

      if (!allowRetry) {
        onClearDraft();
        messenger.showSnackBar(
          const SnackBar(
            content: Text('પ્રિન્ટર સાથે જોડાણ નિષ્ફળ. બિલ સેવ થઈ ગયું છે.'),
          ),
        );
        return;
      }

      messenger.showSnackBar(
        SnackBar(
          content: const Text(
            'પ્રિન્ટર સાથે જોડાણ નિષ્ફળ. કૃપા કરીને તપાસો કે પ્રિન્ટર ચાલુ છે.',
          ),
          action: SnackBarAction(
            label: 'ફરી પ્રયાસ',
            onPressed: () {
              attemptPrintSavedBill(
                messenger,
                ref,
                billId: billId,
                allowRetry: false,
                desktopKey: desktopKey,
                mobileKey: mobileKey,
                isMounted: isMounted,
                onClearDraft: onClearDraft,
              );
            },
          ),
        ),
      );
    }
  }

  Future<Uint8List?> captureBillImageBytes(
    GlobalKey desktopKey,
    GlobalKey mobileKey,
  ) async {
    final boundary =
        (desktopKey.currentContext?.findRenderObject() as RenderRepaintBoundary?) ??
        (mobileKey.currentContext?.findRenderObject() as RenderRepaintBoundary?);
    
    if (boundary == null || !boundary.attached) return null;

    final ui.Image image = await boundary.toImage(pixelRatio: 2.0);
    final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
    return byteData?.buffer.asUint8List();
  }
}
