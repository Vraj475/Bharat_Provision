import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/localization/app_strings.dart';
import '../../core/widgets/primary_button.dart';
import '../../shared/models/customer_model.dart';
import '../../data/providers.dart';
import 'khata_providers.dart';
import 'package:go_router/go_router.dart';

class CustomerEditScreen extends ConsumerStatefulWidget {
  const CustomerEditScreen({super.key, this.customerId});

  final int? customerId;

  @override
  ConsumerState<CustomerEditScreen> createState() => _CustomerEditScreenState();
}

class _CustomerEditScreenState extends ConsumerState<CustomerEditScreen> {
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _addressController = TextEditingController();


  bool _loading = true;
  Customer? _customer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    if (widget.customerId == null) {
      setState(() => _loading = false);
      return;
    }
    final repo = ref.read(customerRepositoryProvider);
    final customer = await repo.getById(widget.customerId!);
    if (customer != null && mounted) {
      setState(() {
        _customer = customer;
        _nameController.text = customer.nameGujarati;
        _phoneController.text = customer.phone ?? '';
        _addressController.text = customer.address ?? '';
        _loading = false;
      });
    } else {
      setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _addressController.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final name = _nameController.text.trim();
    if (name.isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text(AppStrings.fieldRequired)));
      return;
    }

    final repo = ref.read(customerRepositoryProvider);

    try {
      if (_customer != null) {
        await repo.update(
          _customer!.copyWith(
            nameGujarati: name,
            phone: _phoneController.text.trim().isEmpty
                ? null
                : _phoneController.text.trim(),
            address: _addressController.text.trim().isEmpty
                ? null
                : _addressController.text.trim(),
          ),
        );
      } else {
        await repo.insert(
          Customer(
            nameGujarati: name,
            phone: _phoneController.text.trim().isEmpty
                ? null
                : _phoneController.text.trim(),
            address: _addressController.text.trim().isEmpty
                ? null
                : _addressController.text.trim(),
            accountType: 'regular',
            creditLimit: 2000.0,
            totalOutstanding: 0.0,
            isActive: true,
            createdAt: DateTime.now().toIso8601String(),
          ),
        );
      }
      ref.invalidate(customerListProvider);
      if (mounted) {
        context.pop();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('ગ્રાહક સફળતાપૂર્વક સેવ થયું')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${AppStrings.errorGeneric} $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.customerId != null
              ? AppStrings.editCustomer
              : AppStrings.addCustomer,
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(
                labelText: AppStrings.customerName,
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _phoneController,
              decoration: const InputDecoration(labelText: AppStrings.phone),
              keyboardType: TextInputType.phone,
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _addressController,
              decoration: const InputDecoration(labelText: AppStrings.address),
              maxLines: 2,
            ),

            const SizedBox(height: 24),
            PrimaryButton(
              label: AppStrings.saveButton,
              icon: Icons.save,
              onPressed: _save,
            ),
          ],
        ),
      ),
    );
  }
}
